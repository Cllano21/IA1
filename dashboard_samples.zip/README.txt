Sales & Inventory Dashboard Demo

1. Instalar dependencias:
   pip install -r requirements.txt

2. Ejecutar la app:
   python dashboard_app.py

3. Abrir http://127.0.0.1:8050 en navegador.

Datos: CSVs de ejemplo simulando Navigator, VIP y PowerBI.
